<?php include('header.php'); ?>
<title>Terms & Conditions - <?php echo $title; ?></title>
			<section class="no-padding sh-about">
				<div class="sub-header ">
					<h3>TERMS & CONDITIONS</h3>
					<ol class="breadcrumb">
 						<li>
 							<a href="#"><i class="fa fa-home"></i> HOME     </a>
 						</li>
 						<li class="active">TERMS & CONDITIONS</li>
 					</ol>
				</div>
			</section>
			<!-- /Sub header -->

			<section class="no-padding">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="title-block text-center title-pd">
								<span class="top-title"></span>
								<h2>READ CARFULLY</h2>
								<p class="sub-title">As always, partners grows with you!</p>
								<span class="bottom-title"></span>
							</div>
						</div>
						<div class="col-md-12">
							<p align=justify> These regulations concern the provision of investment services by the <strong><?php echo $title; ?></strong> company to its customers.
							<br>
							<br> Please read these 'Terms and Conditions' carefully before using our Site.
							<br> By using our Site, you are agreeing to be legally bound by these 'Terms and Conditions' and are committing fully and unconditionally to the obligations set out herein.
							<br> Please note that these 'Terms and Conditions' shall form a binding contract between you and us.
							<br>
							<br> <strong>1. REGISTRATION OF THE USER ON THE SITE</strong>
							<br>
							<br> 1.1. In order to use the services of the company, the User has to complete the registration procedure, as a result of which the account is created.
							<br> 1.2. By the fact of registration, the User confirms acceptance of all the provisions of Terms of Use and accepts all rights and obligations arising in this connection.
							<br> 1.3. To participate in the project allowed persons over the age of 18. By registering, the User confirms that he/she is of legal age. By registering, the User also agrees and confirms that he/she uses the site in its sole discretion, voluntarily and on his/her own initiative.
							<br> 1.4. The User undertakes to provide the Company only with only true and current personal information and e-mail address (Registration Data).
							<br> 1.5. The User agrees to the best of their abilities to maintain and update the Registration Data to keep it current and complete.
							<br> 1.6. The User undertakes to store all authorization data (password, login) in an environment where third parties are not admitted to them, and take all available actions to protect their personal data from unauthorized and malicious access.
							<br> 1.7. Each User can have only one account registered from one PC or IP address. Please note! If we find out you have multiple accounts, all of them will be blocked and the funds forfeited without any notice.
							<br> 1.8. After passing the registration procedure, the User who has expressed a desire to participate in the investment process of the Company becomes the 'Investor'.
							<br> 1.9. If you are not ready to accept the terms written herewith, please do not register for an account.
							<br>
							<br> <strong>2. INVESTMENT POLICY</strong>
							<br>
							<br> 2.1. Every deposit is considered as a private transaction between the Company and the Investor.
							<br> 2.2. A deposit is considered active if its term has not expired according to the relevant investment plan.
							<br> 2.3. All accruals in the Personal Account are made according to the chosen investment package.
							<br> 2.4. Accruals and payouts to the Investor are made only in the currency of the electronic payment system used by that Investor to make deposit.
							<br> 2.5. The Investor has the right to freely dispose of the funds that are on his personal account
							<br> 2.6. Payment of referral commissions is made only in the currency of the electronic payment system used by a particular referral to make deposit. The Company does not pay referral commissions for deposits made by a referral from their account balance.
							<br> 2.7. The Investor acknowledges and agrees that he has been notified that he cannot unilaterally change their billing information submitted during registration.
							<br> 2.8. The Investor agrees that before creating a deposit, he carefully checked all the details about the deposit and fully agreed with all the terms and conditions of the selected investment plan.
							<br> 2.9. The Investor acknowledges and agrees that investment plan that he has chosen cannot be changed after a deposit has been created.
							<br> 2.10. The nominal value of all active deposits cannot be withdrawn from the system until the deposits expire.
							<br>
							<br> <strong>2.REINVESTMENT POLICY</strong>
							<br>
							<br> 2.11. Reinvestment from account balance starts from plan 1, but reivestment from account balance is only allowed once in plan 1 whereas unlimited on plan 2, 3, and 4.
							<br></br> 2.12. Secondly Investing below your previous withdrawal starts from plan 3.
							<br>
							<br> For example when you withdraw 270 you next deposit should be 271 or more till you get to plan 3 Them you can invest below your previous withdrawal.
							<br>
							<br> <strong>3. CONFIDENTIALITY</strong>
							<br>
							<br> 3.1. The company adheres to the principles of anonymity and confidentiality of personal data of its customers.
							<br> 3.2. The company does not divulge any data of its customers to third parties that contain their personal information, contact details, as well as the fact of participation. The only information that is displayed publicly is current deposit statistics, which includes the amount of the deposit, payment method and username of the investor.
							<br> 3.3. Investor's real name is never shown publicly and is never displayed. Investor is allowed to pick any username except for forbidden ones.
							<br> 3.4. The Company guarantees that customer's data is never, under any circumstances, will fall into the database used for spam by third parties.
							<br> 3.5. All the data giving by customers will only be used to improve the service that we provide them.
							<br>
							<br> 04. ELECTRONIC COMMUNICATION</strong>
							<br>
							<br> 4.1. When using the site, you accept that communication with us will be mainly electronic. You agree to this electronic means of communication and you acknowledge that all contracts, notices, information and other communications that we provide to you electronically comply with any legal requirement that such communications be in writing.
							<br>
							<br> <strong>5. DISCLAIMER</strong>
							<br>
							<br> 5.1. The Company is not a defendant for the accuracy or correctness of the Customerâ€™s perception of the information content presented on the site. All information posted on the site is advisory and informational and should not be considered as a call for any action.
							<br> 5.2. The Company shall not be liable for any losses arising from delay in the transmission of the funds due to causes beyond its control. Delays may result from failures in the operation of electronic payment systems that the Investor uses to conduct the investment process or withdraw funds.
							<br> 5.3. The Company does not bear responsibility for mistakes made by the Investor when completing the payment details.
							<br> 5.4. The Company is not responsible for temporary interruptions of work or failures in the use of the site, including any failures that have been caused by the service provider.
							<br> 5.5. The Company shall not be liable for any losses arising from failure of the Investor to hold his PC systems free from malicious software used by third parties to get unauthorized access to Investorâ€™s account. It is Investorâ€™s sole responsibility to check his PC for trojans, key loggers and other malware.
							<br> 5.6. The Company cannot be a defendant for failures in the work of the site, if they were caused by force majeure circumstances.
							<br> 5.7. The website administration shall not be liable to User for termination of access to the Website if the User violates any provisions of these 'Terms and Conditions'.
							<br>
							<br> <strong>6. MODIFYING THE WEBSITE</strong>
							<br>
							<br> 6.1. The site may develop and change over time. The site administration reserves the right to itself for information change on the given site without the prevention. We may amend, update, add to, replace or withdraw elements of the site at any time at our sole discretion.
							<br>
							<br> <strong>7. CHANGES TO THESE RULES</strong>
							<br>
							<br> 7.1. The Company is entitled to unilaterally change these 'Terms and Conditions' without notice. Changes shall take legal effect immediately on publication
							<br> </p>
						</div>
					</div>
				</div>
			</section>
			<!-- /about description -->
<?php include('footer.php'); ?>