<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $fullname = isset($_POST['fullname']) ? $_POST['fullname'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $subject = isset($_POST['subject']) ? $_POST['subject'] : '';
    $msg = isset($_POST['msg']) ? $_POST['msg'] : '';

    // Validate form data (you might want to add more validation)
    if (empty($subject) || empty($msg)) {
        echo '0'; // Validation failed
        exit();
    }

    // Compose email message
    $to = 'admin@crypto-lux.ltd';
    $subject = 'Support Form Submission - ' . $subject;
    $message = "Full Name: $fullname\n";
    $message .= "Email: $email\n";
    $message .= "Username: $username\n\n";
    $message .= "Subject: $subject\n";
    $message .= "Message:\n$msg";

    // Send email
    $headers = 'From: ' . $email . "\r\n" .
               'Reply-To: ' . $email . "\r\n" .
               'X-Mailer: PHP/' . phpversion();

    if (mail($to, $subject, $message, $headers)) {
        echo '1'; // Email sent successfully
    } else {
        echo '0'; // Email sending failed
    }
} else {
    // Redirect if accessed directly
    header('Location: ../');
}

?>
