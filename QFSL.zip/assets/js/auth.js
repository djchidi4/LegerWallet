
        // Login Scripts
        $(function(){
                $('#signup').submit(function(e) {
                    e.preventDefault();

            // Get values from the form
            var uname = $('#email_username').val();
            var u_pass = $('#u_password').val();

            // Remove any existing error messages
            $(".error").remove();

            // Validate the form fields
            if (uname.length < 1) {
                $('#email_err').after('<span class="error mt3"><i class="uil uil-exclamation-triangle"></i> Your email or username is required</span>');
            }
            if (u_pass.length < 1) {
                $('#password_err').after('<span class="error mt3"><i class="uil uil-exclamation-triangle"></i> Your password is required</span>');
            }

            // If fields are not empty, submit the form
            if (uname.length > 1 && u_pass.length > 1) {
                var lgbtn = document.getElementById("login-btn");
                lgbtn.innerHTML='<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Logging in...';
                $("#login-btn").attr("disabled", true);

                // Simulate form submission after validation
                document.getElementById("signup").submit();
            }
        });
    });
    
    // Registration Scripts
    
    $(function(){
        $('#u_fullname').on('focus', function(){
            $('#fullname_icon').addClass('active');
        });
        $('#u_email').on('focus', function(){
            $('#email_icon').addClass('active');
        });
        $('#u_email').on('blur', function(){
            $('#email_icon').removeClass('active');
        });

        $('#u_username').on('focus', function(){
            $('#u_username_icon').addClass('active');
        });
        $('#u_username').on('blur', function(){
            $('#u_username_icon').removeClass('active');
        });

        $('#u_password').on('focus', function(){
            $('#u_password_icon').addClass('active');
            $('#togglePassword').addClass('active');
        });
        $('#u_password').on('blur', function(){
            $('#u_password_icon').removeClass('active');
            $('#togglePassword').removeClass('active');
        });

        $('#u_password2').on('focus', function(){
            $('#u_password_icon2').addClass('active');
        });
        $('#u_password2').on('blur', function(){
            $('#u_password_icon2').removeClass('active');
        });
        
        const togglePassword = document.querySelector('#togglePassword');
        const u_password = document.querySelector('#u_password');
        const u_password2 = document.querySelector('#u_password2');
     
        togglePassword.addEventListener('click', function (e) {
        
        const type = u_password.getAttribute('type') === 'password' ? 'text' : 'password';
        u_password.setAttribute('type', type);
        
        const type2 = u_password2.getAttribute('type') === 'password' ? 'text' : 'password';
        u_password2.setAttribute('type', type2);
        
        this.classList.toggle('uil-eye-slash');
    
        });
        var browser = '';
        var browserVersion = 0;
    
        if (/Opera[\/\s](\d+\.\d+)/.test(navigator.userAgent)) {
            browser = 'Opera';
        } else if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)) {
            browser = 'MSIE';
        } else if (/Navigator[\/\s](\d+\.\d+)/.test(navigator.userAgent)) {
            browser = 'Netscape';
        } else if (/Chrome[\/\s](\d+\.\d+)/.test(navigator.userAgent)) {
            browser = 'Chrome';
        } else if (/Safari[\/\s](\d+\.\d+)/.test(navigator.userAgent)) {
            browser = 'Safari';
            /Version[\/\s](\d+\.\d+)/.test(navigator.userAgent);
            browserVersion = new Number(RegExp.$1);
        } else if (/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent)) {
            browser = 'Firefox';
        }
        if(browserVersion === 0){
            browserVersion = parseFloat(new Number(RegExp.$1));
        }
        $('#browser').val(browser+ "-" +browserVersion);
        
        
        $('#signup').submit(function(e) {
            e.preventDefault();
            var u_fullname = $('#u_fullname').val();
            var u_email = $('#u_email').val();
            var u_username = $('#u_username').val();
            var u_password = $('#u_password').val();
            var u_password2 = $('#u_password2').val();

            $(".error").remove();
            
            if (u_fullname.length < 1) {
                $('#fullname_err').after('<span class="error mt3"><i class="uil uil-exclamation-triangle"></i> Your email fullname is required</span>');
            }
            if (u_email.length < 1) {
                $('#email_err').after('<span class="error mt3"><i class="uil uil-exclamation-triangle"></i> Your email address is required</span>');
            }
            if (u_username.length < 1) {
                $('#u_username_err').after('<span class="error mt3"><i class="uil uil-exclamation-triangle"></i> Please enter a unique username</span>');
            }
            if (u_password.length < 8) {
                $('#u_password_err').after('<span class="error mt3"><i class="uil uil-exclamation-triangle"></i> Please enter a password 8 characters long</span>');
            }
            if (u_password != u_password2) {
                $('#u_password2_err').after('<span class="error mt3"><i class="uil uil-exclamation-triangle"></i> Your passwords do not match</span>');
            }
            if (u_username.length > 1 && u_email.length > 1 && u_password.length > 6 && u_password == u_password2) {
                var lgbtn = document.getElementById("signup-btn");
                lgbtn.innerHTML='<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Creating your account...';
                $("#signup-btn").attr("disabled", true);
                signup.submit();
            }
        });
    });